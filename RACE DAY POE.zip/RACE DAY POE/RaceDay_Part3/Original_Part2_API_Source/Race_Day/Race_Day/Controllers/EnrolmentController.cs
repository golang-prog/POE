using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Race_Day.Data;
using Race_Day.Models;
using System.Security.Claims;

namespace Race_Day.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class EnrolmentController : ControllerBase
{
    private readonly ApplicationDbcontext _db;
    public EnrolmentController(ApplicationDbcontext db) => _db = db;

    private async Task<User?> CurrentProfile()
    {
        var email = User.FindFirstValue(ClaimTypes.Email);
        if (string.IsNullOrWhiteSpace(email)) return null;
        return await _db.users.FirstOrDefaultAsync(u => u.Username == email);
    }

    public sealed class EnrolRequest { public Guid CategoryId { get; set; } public decimal AmountPaid { get; set; } }

    [HttpPost]
    [Authorize(Roles = "Participant,Admin")]
    public async Task<IActionResult> Enrol([FromBody] EnrolRequest request)
    {
        var profile = await CurrentProfile();
        if (profile == null) return BadRequest("Participant profile is not linked to this account.");
        var category = await _db.categories.FindAsync(request.CategoryId);
        if (category == null) return NotFound("Category not found.");
        var exists = await _db.enrolments.AnyAsync(e => e.UserId == profile.UserId && e.CategoryId == request.CategoryId);
        if (exists) return Conflict("You are already enrolled in this category.");
        var enrolment = new Enrolment { UserId = profile.UserId, CategoryId = category.CategoryId,
            EventId = category.EventId, enrolment_date = DateOnly.FromDateTime(DateTime.UtcNow),
            enrolment_status = "Confirmed", payment_status = request.AmountPaid > 0 ? "Paid" : "Pending",
            amount_paid = request.AmountPaid, paid_date = request.AmountPaid > 0 ? DateOnly.FromDateTime(DateTime.UtcNow) : DateOnly.MinValue };
        _db.enrolments.Add(enrolment);
        // Create the participant's event entry at the same time as the enrolment.
        var nextBib = (await _db.participant_Events.CountAsync()) + 1001;
        _db.participant_Events.Add(new Participant_Event { UserId = profile.UserId, EventId = category.EventId,
            CategoryId = category.CategoryId, bib_number = nextBib, fining_position = 0,
            finish_time_seconds = TimeOnly.MinValue, entry_status = "Enrolled",
            entered_at = DateOnly.FromDateTime(DateTime.UtcNow) });
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(MyEnrolments), new { id = enrolment.EnrolmentId }, enrolment);
    }

    [HttpGet("mine")]
    [Authorize(Roles = "Participant,Admin")]
    public async Task<IActionResult> MyEnrolments()
    {
        var profile = await CurrentProfile();
        if (profile == null) return NotFound("Participant profile not found.");
        var rows = await (from e in _db.enrolments join ev in _db.events on e.EventId equals ev.EventId
                          join c in _db.categories on e.CategoryId equals c.CategoryId
                          where e.UserId == profile.UserId
                          select new { e.EnrolmentId, e.EventId, ev.EventName, ev.EventDate, c.CategoryName,
                              e.enrolment_date, e.enrolment_status, e.payment_status, e.amount_paid }).ToListAsync();
        return Ok(rows);
    }

    [HttpGet("event/{eventId:guid}")]
    [Authorize(Roles = "Organiser,Admin")]
    public async Task<IActionResult> ByEvent(Guid eventId)
    {
        var rows = await (from e in _db.enrolments join u in _db.users on e.UserId equals u.UserId
                          join c in _db.categories on e.CategoryId equals c.CategoryId
                          where e.EventId == eventId
                          select new { e.EnrolmentId, u.UserId, u.FirstName, u.LastName, u.Username,
                              c.CategoryName, e.enrolment_date, e.enrolment_status, e.payment_status, e.amount_paid }).ToListAsync();
        return Ok(rows);
    }
}
