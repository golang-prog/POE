using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Race_Day.Data;
using Race_Day.Models;
using Race_Day.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Race_Day.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        public readonly ApplicationDbcontext dbcontext;
        public UserController(ApplicationDbcontext dbcontext)
        {
            this.dbcontext = dbcontext;
        }
        [HttpGet]
        public IActionResult GetAllUsers()
        {
            var Users = dbcontext.users.ToList();
            return Ok(Users);
        }
        [HttpGet]
        [Route("{id:guid}")]

        public IActionResult GetUserByID(Guid id)
        {
            var User = dbcontext.users.Find(id);
            if (User == null) return NotFound();
            return Ok(User);
        }
        [HttpPost]
        public IActionResult AddNewUser(Add_New_UserDTO addDTO)
        {
            var user = new User
            {
                Username = addDTO.Username,
                FirstName = addDTO.FirstName,
                LastName = addDTO.LastName,
                DateOfBirth = addDTO.DateOfBirth,
                PhoneNumber = addDTO.PhoneNumber,

                // server-controlled:
                CreatedAt = DateTime.UtcNow,
                LastLogin = DateTime.UtcNow,// TODO : Update this value when the user logs in
                IsActive = true,// database, the user is active by default
            };

            dbcontext.users.Add(user);
            dbcontext.SaveChanges();
            return Ok("User was added successfully");
        }
        [HttpPut]
        [Route("{id:guid}")]
        public IActionResult EditUserPorfile(Guid id, Edit_Existing_UserDTO editDTO)
        {
            var user = dbcontext.users.Find(id);
            if (user == null) return NotFound($"No user was found with {id}");
            if (editDTO.Username != null) user.Username = editDTO.Username;
            if (editDTO.FirstName != null) user.FirstName = editDTO.FirstName;
            if (editDTO.LastName != null) user.LastName = editDTO.LastName;
            if (editDTO.DateOfBirth != null) user.DateOfBirth = editDTO.DateOfBirth.Value;
            if (editDTO.PhoneNumber != null) user.PhoneNumber = editDTO.PhoneNumber;


            dbcontext.SaveChanges();
            return Ok("User profile updated.");

        }
        [HttpDelete]
        [Route("{id:guid}")]
        public IActionResult RemoveUser(Guid id)
        {
        var user = dbcontext.users.Find(id);
            if (user == null) return NotFound($"No user was found with {id}");

            dbcontext.users.Remove(user);
            dbcontext.SaveChanges();
            return Ok("User was Deleted successfully");
        }

        [Authorize]
        [HttpGet("me/profile")]
        public async Task<IActionResult> MyProfile()
        {
            var email = User.FindFirstValue(ClaimTypes.Email);
            var profile = await dbcontext.users.FirstOrDefaultAsync(u => u.Username == email);
            if (profile == null) return NotFound("Profile not found.");
            return Ok(profile);
        }

        public sealed class ProfileUpdateRequest
        {
            public string? FirstName { get; set; } public string? LastName { get; set; }
            public DateOnly? DateOfBirth { get; set; } public string? PhoneNumber { get; set; }
        }

        [Authorize]
        [HttpPut("me/profile")]
        public async Task<IActionResult> UpdateMyProfile([FromBody] ProfileUpdateRequest request)
        {
            var email = User.FindFirstValue(ClaimTypes.Email);
            var profile = await dbcontext.users.FirstOrDefaultAsync(u => u.Username == email);
            if (profile == null) return NotFound("Profile not found.");
            if (request.FirstName != null) profile.FirstName = request.FirstName;
            if (request.LastName != null) profile.LastName = request.LastName;
            if (request.DateOfBirth.HasValue) profile.DateOfBirth = request.DateOfBirth.Value;
            if (request.PhoneNumber != null) profile.PhoneNumber = request.PhoneNumber;
            await dbcontext.SaveChangesAsync();
            return Ok(profile);
        }
    }
}
