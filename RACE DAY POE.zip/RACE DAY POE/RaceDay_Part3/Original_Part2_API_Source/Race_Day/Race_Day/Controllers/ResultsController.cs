using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Race_Day.Data;
using Race_Day.Models;
using System.Security.Claims;

namespace Race_Day.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class ResultsController : ControllerBase
{
    private readonly ApplicationDbcontext _db;
    public ResultsController(ApplicationDbcontext db) => _db = db;
    private async Task<User?> CurrentProfile()
    {
        var email = User.FindFirstValue(ClaimTypes.Email);
        return string.IsNullOrWhiteSpace(email) ? null : await _db.users.FirstOrDefaultAsync(u => u.Username == email);
    }
    [HttpGet("mine")]
    [Authorize(Roles = "Participant,Admin")]
    public async Task<IActionResult> Mine()
    {
        var profile = await CurrentProfile();
        if (profile == null) return NotFound("Participant profile not found.");
        var rows = await (from r in _db.results join pe in _db.participant_Events on r.ParticipantEventId equals pe.Participant_EventId
                          join ev in _db.events on pe.EventId equals ev.EventId where pe.UserId == profile.UserId
                          select new { ev.EventName, ev.EventDate, r.finish_position, r.finish_time_seconds,
                              r.pace_pace_km, r.overall_rank, r.prize_money, r.category_rank }).ToListAsync();
        return Ok(rows);
    }
    [HttpGet("event/{eventId:guid}")]
    [Authorize(Roles = "Organiser,Admin")]
    public async Task<IActionResult> ByEvent(Guid eventId)
    {
        var rows = await (from pe in _db.participant_Events
                          join u in _db.users on pe.UserId equals u.UserId
                          join r0 in _db.results on pe.Participant_EventId equals r0.ParticipantEventId into resultGroup
                          from r in resultGroup.DefaultIfEmpty()
                          where pe.EventId == eventId
                          select new { pe.Participant_EventId, u.FirstName, u.LastName, pe.bib_number,
                              finish_position = r == null ? "" : r.finish_position,
                              finish_time_seconds = r == null ? "" : r.finish_time_seconds,
                              pace_pace_km = r == null ? "" : r.pace_pace_km,
                              overall_rank = r == null ? "" : r.overall_rank,
                              prize_money = r == null ? 0m : r.prize_money,
                              category_rank = r == null ? "" : r.category_rank }).ToListAsync();
        return Ok(rows);
    }
    public sealed class SaveResultRequest
    {
        public Guid ParticipantEventId { get; set; } public string FinishPosition { get; set; } = "";
        public string FinishTimeSeconds { get; set; } = ""; public string PacePerKm { get; set; } = "";
        public string OverallRank { get; set; } = ""; public decimal PrizeMoney { get; set; }
        public string CategoryRank { get; set; } = "";
    }
    [HttpPost]
    [Authorize(Roles = "Organiser,Admin")]
    public async Task<IActionResult> Save([FromBody] SaveResultRequest request)
    {
        var pe = await _db.participant_Events.FindAsync(request.ParticipantEventId);
        if (pe == null) return NotFound("Participant entry not found.");
        var result = await _db.results.FirstOrDefaultAsync(r => r.ParticipantEventId == request.ParticipantEventId);
        if (result == null)
        {
            result = new Result { ParticipantEventId = request.ParticipantEventId,
                finish_position = request.FinishPosition, finish_time_seconds = request.FinishTimeSeconds,
                pace_pace_km = request.PacePerKm, overall_rank = request.OverallRank,
                prize_money = request.PrizeMoney, category_rank = request.CategoryRank };
            _db.results.Add(result);
        }
        else
        {
            result.finish_position = request.FinishPosition; result.finish_time_seconds = request.FinishTimeSeconds;
            result.pace_pace_km = request.PacePerKm; result.overall_rank = request.OverallRank;
            result.prize_money = request.PrizeMoney; result.category_rank = request.CategoryRank;
        }
        await _db.SaveChangesAsync();
        return Ok(result);
    }
}
