using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Race_Day.Data;
using Race_Day.Models;
using Race_Day.Models.DTOs;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace Race_Day.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        public readonly ApplicationDbcontext dbcontext;
        private readonly IConfiguration _configuration;

        public EventsController(ApplicationDbcontext dbcontext, IConfiguration configuration)
        {
            this.dbcontext = dbcontext;
            _configuration = configuration;
        }
        [HttpGet]
        public IActionResult GetEvents()
        {
            var events = dbcontext.events.ToList();
            return Ok(events);
        }
        [HttpGet]
        [Route("{id:guid}")]
        public IActionResult GetEventById(Guid id)
        {
            var eventItem = dbcontext.events.Find(id);
            if (eventItem == null) return NotFound($"Event with id {id} was not found.");
            return Ok(eventItem);
        }

        
        [HttpPost]
        [Authorize(Roles = "Admin,Organiser")]
        public IActionResult CreateEvent(NewEventDTO newEventDTO)
        {
            
            var newEvent = new Event
            {
                EventName = newEventDTO.EventName,
                EventDate = newEventDTO.EventDate,
                Location = newEventDTO.Location,
                Venue = newEventDTO.Venue,
                DistanceKm = newEventDTO.DistanceKm,
                EventFee = newEventDTO.EventFee,
                EventType = newEventDTO.EventType,
                Status = "Scheduled",


                // server-controlled
                CreatedBy = int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var accountId) ? accountId : 0,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                Now = DateTime.UtcNow
            };

            dbcontext.events.Add(newEvent);
            dbcontext.SaveChanges();

            return CreatedAtAction(
                nameof(GetEventById),
                new { id = newEvent.EventId },
                newEvent
            );
        }
       
        [HttpPut("{id:guid}")]
        [Authorize(Roles = "Admin,Organiser")]
        public IActionResult UpdateEvent(Guid id, [FromBody] UpdateEventDTO updatedEventDTO)
        {
            var existingEvent = dbcontext.events.Find(id);
            if (existingEvent == null) return NotFound($"Event with id {id} was not found.");
            existingEvent.EventName = updatedEventDTO.EventName;
            existingEvent.EventDate = updatedEventDTO.EventDate;
            existingEvent.Location = updatedEventDTO.Location;
            existingEvent.Venue = updatedEventDTO.Venue;
            existingEvent.DistanceKm = updatedEventDTO.DistanceKm;
            existingEvent.EventFee = updatedEventDTO.EventFee;
            existingEvent.EventType = updatedEventDTO.EventType;
            existingEvent.UpdatedAt = DateTime.UtcNow;
            dbcontext.SaveChanges();
            return Ok("Event was updated successfully.");
        }
     
        [HttpDelete("{id:guid}")]
        [Authorize(Roles = "Admin,Organiser")]
        public IActionResult RemoveEvent(Guid id)
        {
            var existingEvent = dbcontext.events.Find(id);
            if (existingEvent == null) return NotFound($"Event with id {id} was not found.");
            dbcontext.events.Remove(existingEvent);
            dbcontext.SaveChanges();
            return Ok("Event was removed successfully.");
        }


        [HttpPost("{id:guid}/banner")]
        [Authorize(Roles = "Admin,Organiser")]
        [RequestSizeLimit(5_000_000)]
        public async Task<IActionResult> UploadBanner(Guid id, IFormFile file)
        {
            var connection = _configuration["AzureBlob:ConnectionString"];
            if (string.IsNullOrWhiteSpace(connection)) return StatusCode(503, "Azure Blob Storage is not configured. Set AzureBlob:ConnectionString.");
            var containerName = _configuration["AzureBlob:ContainerName"] ?? "event-banners";
            var container = new BlobContainerClient(connection, containerName);
            if (file == null || file.Length == 0) return BadRequest("Select an image file.");
            var allowed = new[] { "image/jpeg", "image/png", "image/webp" };
            if (!allowed.Contains(file.ContentType)) return BadRequest("Only JPG, PNG or WEBP images are allowed.");
            var eventItem = await dbcontext.events.FindAsync(id);
            if (eventItem == null) return NotFound("Event not found.");
            await container.CreateIfNotExistsAsync(PublicAccessType.None);
            var extension = Path.GetExtension(Path.GetFileName(file.FileName));
            var blob = container.GetBlobClient($"{id}/{Guid.NewGuid():N}{extension}");
            await using var stream = file.OpenReadStream();
            await blob.UploadAsync(stream, new BlobHttpHeaders { ContentType = file.ContentType });
            eventItem.BannerUrl = blob.Uri.ToString();
            eventItem.UpdatedAt = DateTime.UtcNow;
            await dbcontext.SaveChangesAsync();
            return Ok(new { bannerUrl = eventItem.BannerUrl });
        }
    }
}
