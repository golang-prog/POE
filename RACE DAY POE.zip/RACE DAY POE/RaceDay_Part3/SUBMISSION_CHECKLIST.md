# RaceDay Part 3 final submission checklist

- [ ] Open `RaceDay.Part3.sln` in Visual Studio 2022.
- [ ] Configure the SQL Server connection and private JWT signing key.
- [ ] Run `DATABASE_UPDATES.sql` after backing up the database.
- [ ] Restore NuGet packages and build both API and MVC projects.
- [ ] Run both projects together and verify the API base URL.
- [ ] Test participant registration, login, event enrolment, My Events, My Results and profile update.
- [ ] Test organiser login, event/category CRUD, enrolment list and result recording.
- [ ] Configure Azure Blob Storage and test banner upload if required by the POE.
- [ ] Build and run Docker; verify the API can be reached from the container.
- [ ] Push the source to the required GitHub repository/branch and make genuine meaningful commits.
- [ ] Confirm the GitHub Actions workflow passes.
- [ ] Record and upload the unlisted demonstration video.
- [ ] Add repository and video links to the README and submit the required link.

Do not tick a requirement until it has been tested successfully in your own environment.
