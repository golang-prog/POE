# RaceDay Part 3 upgraded project – setup instructions

## What is included in this package
- Your original Part 2 API source, with JWT bearer authentication registered in Program.cs.
- Participant registration now creates a matching participant profile (`User.Username = account email`).
- New participant enrolment, My Enrolments, organiser event enrolment list, participant results and organiser results API endpoints.
- Enrolment also creates a participant-event entry with a generated bib number.
- Authenticated profile read/update endpoints.
- MVC participant My Events, My Results and Profile pages wired to those API endpoints.
- Organiser enrolment and results pages, including a result-entry form for each event participant.
- Organiser-only event/category writes and Azure Blob banner upload endpoint.
- Existing Dockerfile, GitHub Actions workflow, README and solution/project files.

## Important setup steps (required)
1. Extract the ZIP to a folder such as `C:\Users\YourName\source\repos\RaceDay_Part3`.
2. Open the API project: `Original_Part2_API_Source\Race_Day\Race_Day\Race_Day.csproj`.
3. Open `appsettings.json`. Set `ConnectionStrings:DefaultConnection` to your own SQL Server instance. Do not use the sample lab server if it is not yours.
4. Set a long private `Jwt:Key` using User Secrets or an environment variable (`Jwt__Key`). Do not publish the key to GitHub.
5. Run the SQL script `DATABASE_UPDATES.sql` against your `Race_Day` database. This adds `BannerUrl`.
6. Restore NuGet packages and build the API. The Azure.Storage.Blobs package is included; internet access is needed for restore.
7. To enable banner upload, set `AzureBlob:ConnectionString` in User Secrets/environment variable `AzureBlob__ConnectionString`. Leave it empty if you are not testing image upload; the rest of the API can still run.
8. Run the API using its HTTPS profile (`https://localhost:7173`).
9. Open `RaceDay.MVC\RaceDay.MVC.csproj`. The supplied MVC `ApiSettings:BaseUrl` is `https://localhost:7173/`. Change it if your API starts on another address.
10. In Visual Studio, set both projects to start: right-click solution > Properties > Startup Project > Multiple startup projects > set API and MVC to Start.
11. Register a participant on the website. For an organiser account, register normally, then run the SQL update in `DATABASE_UPDATES.sql` using that account's email to set `Role='Organiser'`.

## Test sequence
1. Start API and MVC.
2. Browse events without signing in.
3. Register a participant and sign in.
4. Open an event, choose a category, enrol, then check My Events.
5. Sign in with an organiser account; create/manage events and categories.
6. Open that event's Enrolments and Results pages. Add a result for a participant entry.
7. Sign back in as participant and check My Results.
8. Test profile updates and, only after configuring Azure, banner upload.

## Known limitations to resolve before final submission
- This package has not been compiled or run in this environment because the .NET SDK and your SQL Server/Azure credentials are not available here. Build and test it in Visual Studio and send any exact error screenshot for correction.
- Existing database migration history may differ. The included SQL script only adds `BannerUrl`; take a database backup first.
- Participant registration initially creates a basic profile with placeholder first/last name, DOB and phone. The participant can update the profile after logging in. If your lecturer requires those details at sign-up, extend the registration form and DTO accordingly.
- The event banner upload uses private blob container storage and returns a blob URI. Configure a suitable access strategy (SAS or authenticated proxy) if browsers must display private blobs.
- The API schema uses `DateOnly` and `TimeOnly`; verify SQL Server compatibility and existing column types.
- GitHub commit history, GitHub repository/branch, successful CI run, and an unlisted demonstration video must be completed using your own accounts. They cannot be fabricated by this ZIP.
- Payment processing is not integrated; enrolment status/payment status are demonstration values only. Do not treat this as real payment processing.

## Docker
Build the MVC image from `RaceDay.MVC` and configure `ApiSettings__BaseUrl` to an address reachable from the container. For a local API on Docker Desktop, use `http://host.docker.internal:5003/` (the API must listen on that HTTP port).
