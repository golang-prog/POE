# RaceDay POE – Part 3 (MVC + Part 2 REST API)

This solution contains the ASP.NET Core MVC website and the supplied Part 2 REST API source, with additional API integration code for the participant/organiser workflows.

## Projects
- `RaceDay.MVC` – responsive Bootstrap MVC website.
- `Original_Part2_API_Source/Race_Day/Race_Day` – Part 2 ASP.NET Core REST API.

## Start in Visual Studio 2022
1. Extract the ZIP.
2. Open `RaceDay.Part3.sln`.
3. Open the API `appsettings.json` and change `ConnectionStrings:DefaultConnection` to the SQL Server instance and database on your computer.
4. Configure a private JWT signing key with User Secrets or environment variable `Jwt__Key`. Keep secrets out of GitHub.
5. Run `DATABASE_UPDATES.sql` against the `Race_Day` database (after taking a backup) to add the `BannerUrl` column.
6. Restore NuGet packages. The API now references `Azure.Storage.Blobs`.
7. Set `RaceDay.MVC/appsettings.json` `ApiSettings:BaseUrl` to the API HTTPS URL. The included API launch profile uses `https://localhost:7173/`.
8. Right-click the solution > Properties > Startup Project > Multiple startup projects. Set `Race_Day` and `RaceDay.MVC` to **Start**.
9. Run the solution.

## First use
- Register through the website to create a Participant account.
- To create an organiser login, register a normal account, then use SQL Server to set its account role to `Organiser`:

```sql
UPDATE dbo.accounts SET Role = 'Organiser' WHERE Email = 'organiser@example.com';
```

- Log in with the relevant account. Do not let public registration select Admin or Organiser roles.

## Included workflows
- Public event listing and event details.
- Participant registration/login, event enrolment, My Events, My Results and profile update.
- Organiser event/category management, event enrolment list and result recording.
- JWT bearer authentication and role checks on protected API operations.
- Event banner upload endpoint using Azure Blob Storage (requires your own Azure connection string).
- Dockerfile and GitHub Actions workflow.

## More instructions
Read `UPGRADE_AND_RUN.md` for database, Azure, test and Docker setup. `DATABASE_UPDATES.sql` contains the small schema change needed for the banner URL.

## Important honest submission checks
This package has been updated from your supplied code but could not be compiled or run in this environment because the .NET SDK, your SQL Server and your Azure account credentials are not available here. Open it in Visual Studio, restore packages, build both projects, run the test sequence in `UPGRADE_AND_RUN.md`, and fix any local configuration or compile errors before submission. Do not claim the Azure upload, Docker, GitHub Actions, or live database has been tested until you have actually tested them.

GitHub branch/commit history, repository push, and an unlisted YouTube demonstration video must be completed in your own accounts. Use meaningful commits as you complete and test each feature; do not fabricate commit history.
