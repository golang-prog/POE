using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Controllers;
using RaceDay.MVC.Models;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers;

public class ParticipantController : BaseController
{
    private readonly IRaceDayApi _api;
    public ParticipantController(IRaceDayApi api) => _api = api;

    public async Task<IActionResult> Index()
    {
        if (!RequireRole("Participant")) return new EmptyResult();
        var events = await _api.GetAsync<List<ApiEvent>>("api/Events", Token) ?? new();
        return View(events.OrderBy(e => e.EventDate).ToList());
    }
    public async Task<IActionResult> MyEvents()
    {
        if (!RequireRole("Participant")) return new EmptyResult();
        var rows = await _api.GetAsync<List<ParticipantEnrolmentVm>>("api/Enrolment/mine", Token) ?? new();
        return View(rows);
    }
    public async Task<IActionResult> MyResults()
    {
        if (!RequireRole("Participant")) return new EmptyResult();
        var rows = await _api.GetAsync<List<ParticipantResultVm>>("api/Results/mine", Token) ?? new();
        return View(rows);
    }
    [HttpGet] public async Task<IActionResult> Enrol(Guid eventId)
    {
        if (!RequireRole("Participant")) return new EmptyResult();
        var categories = await _api.GetAsync<List<ApiCategory>>("api/Category", Token) ?? new();
        ViewBag.EventId = eventId;
        return View(categories.Where(c => c.EventId == eventId).ToList());
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Enrol(Guid eventId, EnrolViewModel model)
    {
        if (!RequireRole("Participant")) return new EmptyResult();
        if (!ModelState.IsValid) return RedirectToAction(nameof(Enrol), new { eventId });
        var response = await _api.SendAsync<object>(HttpMethod.Post, "api/Enrolment",
            new { model.CategoryId, model.AmountPaid }, Token);
        TempData[response.Success ? "Success" : "Error"] = response.Success ? "You have been enrolled." : (response.Error ?? "Enrolment failed.");
        return RedirectToAction(nameof(MyEvents));
    }
    public async Task<IActionResult> Profile()
    {
        if (!RequireRole("Participant")) return new EmptyResult();
        var profile = await _api.GetAsync<ProfileViewModel>("api/User/me/profile", Token) ?? new();
        return View(profile);
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Profile(ProfileViewModel model)
    {
        if (!RequireRole("Participant")) return new EmptyResult();
        var response = await _api.SendAsync<object>(HttpMethod.Put, "api/User/me/profile", new
        { model.FirstName, model.LastName, model.DateOfBirth, model.PhoneNumber }, Token);
        TempData[response.Success ? "Success" : "Error"] = response.Success ? "Profile updated." : (response.Error ?? "Profile update failed.");
        return RedirectToAction(nameof(Profile));
    }
}
