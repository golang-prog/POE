using Microsoft.AspNetCore.Mvc;

namespace RaceDay.MVC.Controllers;

public abstract class BaseController : Controller
{
    protected string? Token => HttpContext.Session.GetString("RaceDay.Token");
    protected string? Role => HttpContext.Session.GetString("RaceDay.Role");
    protected int UserId => HttpContext.Session.GetInt32("RaceDay.UserId") ?? 0;
    protected bool IsLoggedIn => !string.IsNullOrWhiteSpace(Token);

    protected bool RequireLogin()
    {
        if (IsLoggedIn) return true;
        TempData["Error"] = "Please log in to continue.";
        Response.Redirect("/Account/Login");
        return false;
    }

    protected bool RequireRole(params string[] roles)
    {
        if (!RequireLogin()) return false;
        if (roles.Contains(Role, StringComparer.OrdinalIgnoreCase)) return true;
        TempData["Error"] = "You do not have permission to access that page.";
        Response.Redirect("/Home/Index");
        return false;
    }
}
