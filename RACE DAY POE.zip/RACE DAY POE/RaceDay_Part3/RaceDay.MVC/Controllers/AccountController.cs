using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers;

public class AccountController : Controller
{
    private readonly IRaceDayApi _api;
    public AccountController(IRaceDayApi api) => _api = api;

    [HttpGet] public IActionResult Login() => View(new LoginViewModel());
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);
        var result = await _api.SendAsync<ApiLoginResult>(HttpMethod.Post, "api/Auth/login",
            new { model.Email, model.Password });
        if (!result.Success || result.Data?.User is null || string.IsNullOrWhiteSpace(result.Data.Token))
        {
            ModelState.AddModelError("", "Login failed. Check your email and password.");
            return View(model);
        }
        HttpContext.Session.SetString("RaceDay.Token", result.Data.Token);
        HttpContext.Session.SetString("RaceDay.Email", result.Data.User.Email);
        HttpContext.Session.SetInt32("RaceDay.UserId", result.Data.User.UserAccountId);
        // The supplied Part 2 API currently returns Role='User' for every new registration.
        // Treat User as Participant in the MVC navigation only; API authorization must be fixed separately.
        var role = result.Data.User.Role.Equals("User", StringComparison.OrdinalIgnoreCase)
            ? "Participant" : result.Data.User.Role;
        HttpContext.Session.SetString("RaceDay.Role", role);
        return RedirectToAction("Index", role.Equals("Organiser", StringComparison.OrdinalIgnoreCase) ||
            role.Equals("Admin", StringComparison.OrdinalIgnoreCase) ? "Organiser" : "Participant");
    }

    [HttpGet] public IActionResult Register() => View(new RegisterViewModel());
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);
        var result = await _api.SendAsync<JsonMessage>(HttpMethod.Post, "api/Auth/register",
            new { model.Email, model.Password, Role = "Participant" });
        if (!result.Success)
        {
            ModelState.AddModelError("", result.Error ?? "Registration failed.");
            return View(model);
        }
        TempData["Success"] = "Registration successful. Please log in.";
        return RedirectToAction(nameof(Login));
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Home");
    }
    private sealed class JsonMessage { public string? Message { get; set; } }
}
