using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers;

public class HomeController : Controller
{
    private readonly IRaceDayApi _api;
    public HomeController(IRaceDayApi api) => _api = api;

    public async Task<IActionResult> Index()
    {
        var events = await _api.GetAsync<List<ApiEvent>>("api/Events") ?? new();
        return View(events.OrderBy(e => e.EventDate).ToList());
    }
    public async Task<IActionResult> Details(Guid id)
    {
        var item = await _api.GetAsync<ApiEvent>($"api/Events/{id}");
        if (item is null) return NotFound();
        ViewBag.Categories = await _api.GetAsync<List<ApiCategory>>("api/Category") ?? new();
        return View(item);
    }
    public IActionResult Error() => View();
}
