using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Controllers;
using RaceDay.MVC.Models;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers;

public class OrganiserController : BaseController
{
    private readonly IRaceDayApi _api;
    public OrganiserController(IRaceDayApi api) => _api = api;

    public async Task<IActionResult> Index()
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        var events = await _api.GetAsync<List<ApiEvent>>("api/Events", Token) ?? new();
        return View(events.OrderBy(e => e.EventDate).ToList());
    }

    public async Task<IActionResult> Events()
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        return View(await _api.GetAsync<List<ApiEvent>>("api/Events", Token) ?? new());
    }

    [HttpGet] public IActionResult CreateEvent()
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        return View(new EventViewModel());
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateEvent(EventViewModel model)
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        if (!ModelState.IsValid) return View(model);
        var dto = new {
            model.EventName, model.EventDate, Now = DateTime.UtcNow, model.Location, model.Venue,
            model.DistanceKm, model.EventType, model.EventFee, Status = "Scheduled",
            CreatedBy = UserId, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow
        };
        var response = await _api.SendAsync<object>(HttpMethod.Post, "api/Events", dto, Token);
        if (!response.Success) { ModelState.AddModelError("", response.Error ?? "Could not create event."); return View(model); }
        TempData["Success"] = "Event created.";
        return RedirectToAction(nameof(Events));
    }

    [HttpGet] public async Task<IActionResult> EditEvent(Guid id)
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        var e = await _api.GetAsync<ApiEvent>($"api/Events/{id}", Token);
        if (e is null) return NotFound();
        return View(new EventViewModel { EventId=e.EventId, EventName=e.EventName, EventDate=e.EventDate,
            Location=e.Location, Venue=e.Venue, DistanceKm=e.DistanceKm, EventType=e.EventType,
            EventFee=e.EventFee, Status=e.Status, BannerUrl=e.BannerUrl });
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> EditEvent(EventViewModel model)
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        if (!ModelState.IsValid) return View(model);
        var dto = new { model.EventName, model.EventDate, Now=DateTime.UtcNow, model.Location, model.Venue,
            model.DistanceKm, model.EventType, model.EventFee, Status=model.Status, CreatedBy=UserId,
            CreatedAt=DateTime.UtcNow, UpdatedAt=DateTime.UtcNow };
        var r = await _api.SendAsync<object>(HttpMethod.Put, $"api/Events/{model.EventId}", dto, Token);
        if (!r.Success) { ModelState.AddModelError("", r.Error ?? "Could not update event."); return View(model); }
        if (model.Banner is not null)
        {
            var upload = await _api.UploadAsync($"api/Events/{model.EventId}/banner", model.Banner, Token);
            if (!upload.Success) TempData["Error"] = "Event updated, but banner upload failed. Check API Blob Storage setup.";
        }
        TempData["Success"] = "Event updated.";
        return RedirectToAction(nameof(Events));
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteEvent(Guid id)
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        var r = await _api.SendAsync<object>(HttpMethod.Delete, $"api/Events/{id}", null, Token);
        TempData[r.Success ? "Success" : "Error"] = r.Success ? "Event deleted." : (r.Error ?? "Delete failed.");
        return RedirectToAction(nameof(Events));
    }

    public async Task<IActionResult> Categories(Guid eventId)
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        var all = await _api.GetAsync<List<ApiCategory>>("api/Category", Token) ?? new();
        ViewBag.EventId = eventId;
        return View(all.Where(c => c.EventId == eventId).ToList());
    }
    [HttpGet] public IActionResult CreateCategory(Guid eventId)
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        return View(new CategoryViewModel { EventId = eventId });
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateCategory(CategoryViewModel model)
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        if (model.MinAge > model.MaxAge) ModelState.AddModelError(nameof(model.MaxAge), "Maximum age must be greater than minimum age.");
        if (!ModelState.IsValid) return View(model);
        var dto = new { model.EventId, model.CategoryName, model.MinAge, model.MaxAge, model.GenderRestrictions,
            model.MaxParticipants, CreatedBy = HttpContext.Session.GetString("RaceDay.Email") ?? "organiser",
            CreatedAt = DateTime.UtcNow };
        var r = await _api.SendAsync<object>(HttpMethod.Post, "api/Category", dto, Token);
        if (!r.Success) { ModelState.AddModelError("", r.Error ?? "Could not create category."); return View(model); }
        return RedirectToAction(nameof(Categories), new { eventId=model.EventId });
    }
    public async Task<IActionResult> Enrolments(Guid eventId)
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        ViewBag.EventId = eventId;
        var rows = await _api.GetAsync<List<OrganiserEnrolmentVm>>($"api/Enrolment/event/{eventId}", Token) ?? new();
        return View(rows);
    }
    public async Task<IActionResult> Results(Guid eventId)
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        ViewBag.EventId = eventId;
        var rows = await _api.GetAsync<List<OrganiserResultVm>>($"api/Results/event/{eventId}", Token) ?? new();
        return View(rows);
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveResult(ResultViewModel model, Guid eventId)
    {
        if (!RequireRole("Organiser", "Admin")) return new EmptyResult();
        var response = await _api.SendAsync<object>(HttpMethod.Post, "api/Results", new {
            model.ParticipantEventId, model.FinishPosition, model.FinishTimeSeconds, model.PacePerKm,
            model.OverallRank, model.PrizeMoney, model.CategoryRank }, Token);
        TempData[response.Success ? "Success" : "Error"] = response.Success ? "Result saved." : (response.Error ?? "Could not save result.");
        return RedirectToAction(nameof(Results), new { eventId });
    }
}
