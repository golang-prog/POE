namespace RaceDay.MVC.Services;

public interface IRaceDayApi
{
    Task<T?> GetAsync<T>(string path, string? token = null);
    Task<ApiResponse<T>> SendAsync<T>(HttpMethod method, string path, object? body = null, string? token = null);
    Task<ApiResponse<string>> UploadAsync(string path, IFormFile file, string? token = null);
}
public sealed record ApiResponse<T>(bool Success, T? Data, string? Error, int StatusCode);
