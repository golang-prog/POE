using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDay.MVC.Services;

public sealed class RaceDayApi : IRaceDayApi
{
    private readonly HttpClient _http;
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true
    };

    public RaceDayApi(HttpClient http) => _http = http;

    private HttpRequestMessage Create(HttpMethod method, string path, string? token)
    {
        var request = new HttpRequestMessage(method, path);
        if (!string.IsNullOrWhiteSpace(token))
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        return request;
    }

    public async Task<T?> GetAsync<T>(string path, string? token = null)
    {
        using var request = Create(HttpMethod.Get, path, token);
        using var response = await _http.SendAsync(request);
        if (!response.IsSuccessStatusCode) return default;
        return await response.Content.ReadFromJsonAsync<T>(JsonOptions);
    }

    public async Task<ApiResponse<T>> SendAsync<T>(HttpMethod method, string path, object? body = null, string? token = null)
    {
        using var request = Create(method, path, token);
        if (body is not null) request.Content = JsonContent.Create(body, options: JsonOptions);
        using var response = await _http.SendAsync(request);
        var raw = await response.Content.ReadAsStringAsync();
        if (!response.IsSuccessStatusCode)
            return new(false, default, string.IsNullOrWhiteSpace(raw) ? response.ReasonPhrase : raw, (int)response.StatusCode);
        T? data = default;
        try
        {
            if (typeof(T) == typeof(string)) data = (T)(object)raw;
            else if (!string.IsNullOrWhiteSpace(raw) && raw.TrimStart().StartsWith("{") || raw.TrimStart().StartsWith("["))
                data = JsonSerializer.Deserialize<T>(raw, JsonOptions);
        }
        catch (JsonException) { }
        return new(true, data, null, (int)response.StatusCode);
    }

    public async Task<ApiResponse<string>> UploadAsync(string path, IFormFile file, string? token = null)
    {
        using var request = Create(HttpMethod.Post, path, token);
        using var content = new MultipartFormDataContent();
        await using var stream = file.OpenReadStream();
        using var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
        content.Add(fileContent, "file", Path.GetFileName(file.FileName));
        request.Content = content;
        using var response = await _http.SendAsync(request);
        var raw = await response.Content.ReadAsStringAsync();
        return new(response.IsSuccessStatusCode, raw, response.IsSuccessStatusCode ? null : raw, (int)response.StatusCode);
    }
}
