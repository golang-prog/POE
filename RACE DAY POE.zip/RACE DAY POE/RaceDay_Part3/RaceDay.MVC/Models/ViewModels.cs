using System.ComponentModel.DataAnnotations;

namespace RaceDay.MVC.Models;

public sealed class LoginViewModel
{
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, DataType(DataType.Password)] public string Password { get; set; } = "";
}
public sealed class RegisterViewModel
{
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, MinLength(8), DataType(DataType.Password)] public string Password { get; set; } = "";
    [Required, Compare(nameof(Password)), DataType(DataType.Password), Display(Name="Confirm password")]
    public string ConfirmPassword { get; set; } = "";
}
public sealed class EventViewModel
{
    public Guid EventId { get; set; }
    [Required, StringLength(120)] public string EventName { get; set; } = "";
    [Required] public DateOnly EventDate { get; set; } = DateOnly.FromDateTime(DateTime.Today.AddMonths(1));
    [Required] public string Location { get; set; } = "";
    [Required] public string Venue { get; set; } = "";
    [Range(0.1, 500)] public float DistanceKm { get; set; }
    [Required] public string EventType { get; set; } = "Road Race";
    [Range(0, 100000)] public float EventFee { get; set; }
    public string Status { get; set; } = "Scheduled";
    public IFormFile? Banner { get; set; }
    public string? BannerUrl { get; set; }
}
public sealed class CategoryViewModel
{
    public Guid CategoryId { get; set; }
    [Required] public Guid EventId { get; set; }
    [Required] public string CategoryName { get; set; } = "";
    [Range(0, 120)] public int MinAge { get; set; }
    [Range(0, 120)] public int MaxAge { get; set; }
    public string GenderRestrictions { get; set; } = "Open";
    [Range(1, 100000)] public int MaxParticipants { get; set; } = 100;
}
public sealed class EnrolViewModel
{
    [Required] public Guid CategoryId { get; set; }
    [Range(0, 100000)] public decimal AmountPaid { get; set; }
}
public sealed class ResultViewModel
{
    public Guid ParticipantEventId { get; set; }
    [Required] public string FinishPosition { get; set; } = "";
    [Required] public string FinishTimeSeconds { get; set; } = "";
    public string PacePerKm { get; set; } = "";
    public string OverallRank { get; set; } = "";
    public decimal PrizeMoney { get; set; }
    public string CategoryRank { get; set; } = "";
}
public sealed class ProfileViewModel
{
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string PhoneNumber { get; set; } = "";
    public DateOnly? DateOfBirth { get; set; }
    public IFormFile? ProfilePicture { get; set; }
}
public sealed class ApiEvent
{
    public Guid EventId { get; set; }
    public string EventName { get; set; } = "";
    public DateOnly EventDate { get; set; }
    public string Location { get; set; } = "";
    public string Venue { get; set; } = "";
    public float DistanceKm { get; set; }
    public string EventType { get; set; } = "";
    public float EventFee { get; set; }
    public string Status { get; set; } = "";
    public string? BannerUrl { get; set; }
}
public sealed class ApiCategory
{
    public Guid CategoryId { get; set; }
    public Guid EventId { get; set; }
    public string CategoryName { get; set; } = "";
    public int MinAge { get; set; }
    public int MaxAge { get; set; }
    public string GenderRestrictions { get; set; } = "";
    public int MaxParticipants { get; set; }
}
public sealed class ApiLoginResult
{
    public string Token { get; set; } = "";
    public ApiLoginUser? User { get; set; }
}
public sealed class ApiLoginUser
{
    public int UserAccountId { get; set; }
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
}

public sealed class ParticipantEnrolmentVm { public Guid EnrolmentId {get;set;} public Guid EventId {get;set;} public string EventName {get;set;}=""; public DateOnly EventDate {get;set;} public string CategoryName {get;set;}=""; public DateOnly enrolment_date {get;set;} public string enrolment_status {get;set;}=""; public string payment_status {get;set;}=""; public decimal amount_paid {get;set;} }
public sealed class ParticipantResultVm { public string EventName {get;set;}=""; public DateOnly EventDate {get;set;} public string finish_position {get;set;}=""; public string finish_time_seconds {get;set;}=""; public string pace_pace_km {get;set;}=""; public string overall_rank {get;set;}=""; public decimal prize_money {get;set;} public string category_rank {get;set;}=""; }

public sealed class OrganiserEnrolmentVm { public Guid EnrolmentId {get;set;} public Guid UserId {get;set;} public string FirstName {get;set;}=""; public string LastName {get;set;}=""; public string Username {get;set;}=""; public string CategoryName {get;set;}=""; public DateOnly enrolment_date {get;set;} public string enrolment_status {get;set;}=""; public string payment_status {get;set;}=""; public decimal amount_paid {get;set;} }
public sealed class OrganiserResultVm { public Guid Participant_EventId {get;set;} public string FirstName {get;set;}=""; public string LastName {get;set;}=""; public int bib_number {get;set;} public string finish_position {get;set;}=""; public string finish_time_seconds {get;set;}=""; public string pace_pace_km {get;set;}=""; public string overall_rank {get;set;}=""; public decimal prize_money {get;set;} public string category_rank {get;set;}=""; }
