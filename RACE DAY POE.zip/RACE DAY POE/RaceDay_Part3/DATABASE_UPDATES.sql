-- Run against the Race_Day database before running the upgraded API.
-- Adds the event banner URL column required by the Azure Blob upload endpoint.
IF COL_LENGTH('dbo.events', 'BannerUrl') IS NULL
    ALTER TABLE dbo.events ADD BannerUrl nvarchar(1000) NULL;
GO

-- After registering the organiser account through the website, promote it manually:
-- UPDATE dbo.accounts SET Role = 'Organiser' WHERE Email = 'organiser@example.com';
-- Never expose an organiser/admin role choice on public registration.
GO
