using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace Race_Day.Services;

public sealed class BlobStorageService
{
    private readonly string? _connection;
    private readonly string _container;

    public BlobStorageService(string? connection, string container)
    {
        _connection = connection;
        _container = container;
    }

    public async Task<string> UploadAsync(IFormFile file, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(_connection))
            throw new InvalidOperationException("AzureBlob:ConnectionString is not configured.");
        if (file == null || file.Length == 0 || file.Length > 5 * 1024 * 1024)
            throw new InvalidOperationException("Choose an image smaller than 5 MB.");
        var allowed = new[] { "image/jpeg", "image/png", "image/webp" };
        if (!allowed.Contains(file.ContentType.ToLowerInvariant()))
            throw new InvalidOperationException("Only JPEG, PNG or WEBP images are accepted.");

        var container = new BlobContainerClient(_connection, _container);
        await container.CreateIfNotExistsAsync(PublicAccessType.None, cancellationToken: ct);
        var ext = file.ContentType.ToLowerInvariant() switch
        {
            "image/png" => ".png",
            "image/webp" => ".webp",
            _ => ".jpg"
        };
        var blob = container.GetBlobClient($"{Guid.NewGuid():N}{ext}");
        await using var stream = file.OpenReadStream();
        await blob.UploadAsync(stream,
            new BlobHttpHeaders { ContentType = file.ContentType },
            cancellationToken: ct);
        return blob.Uri.ToString();
    }
}
