# Part 2 API work required for RaceDay Part 3

This folder is an integration patch pack for the API you uploaded. It is not a
drop-in replacement for your entire API because the current database model has
different ID types and several required endpoints are absent.

## Apply
1. Back up the API and commit the current working version to Git.
2. Install packages:
   `dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer`
   `dotnet add package Azure.Storage.Blobs`
3. Add `Services/BlobStorageService.cs`.
4. Add the model properties shown in `Models/Required_Model_Changes.txt`.
5. Update Program.cs using `Program.cs.REPLACEMENT.txt`. Preserve any extra services
   your project uses. Authentication middleware must run before authorization.
6. Patch AuthController.Register so new signups create Participant accounts and
   linked User profile rows.
7. Add profile methods from `UserController.Profile.Endpoints.txt`.
8. Apply organiser authorization and event banner upload from
   `EventsController.Security_And_Banner.txt`.
9. Implement enrolment and results routes following the two implementation guides.
10. Protect all organiser-only create/update/delete routes. Public users must never
    be allowed to register as Organiser or Admin.
11. Configure secrets with User Secrets, not in appsettings.json:
   `dotnet user-secrets init`
   `dotnet user-secrets set "Jwt:Key" "a-long-random-secret-of-at-least-32-characters"`
   `dotnet user-secrets set "Jwt:Issuer" "RaceDayAPI"`
   `dotnet user-secrets set "Jwt:Audience" "RaceDayMVC"`
   `dotnet user-secrets set "AzureBlob:ConnectionString" "YOUR_STORAGE_CONNECTION_STRING"`
   `dotnet user-secrets set "AzureBlob:Container" "raceday"`
12. Add migration and update database after reviewing it:
   `dotnet ef migrations add Part3ProfileMedia`
   `dotnet ef database update`
13. Test registration, login, JWT-protected routes, profile, upload, enrolment and results
    in Swagger before testing MVC.

## Important
- Your uploaded source has `User.UserId` as Guid and `UserAccount.UserAccountId` as int.
  Do not treat these as interchangeable. The new UserAccountId FK property links them.
- Existing accounts need linked User profile records.
- Azure keys stay in the API only. MVC uploads images to the API as multipart form data.
- An organiser account should be provisioned securely by an administrator.
- Review every migration and test with a development database before production.
